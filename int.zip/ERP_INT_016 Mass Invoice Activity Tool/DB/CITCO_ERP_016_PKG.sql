--------------------------------------------------------
--  File created - March-22-2023   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Package CITCO_ERP_016_PKG
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE PACKAGE "CITCO_INT"."CITCO_ERP_016_PKG" 
AS
  FUNCTION format_error_msg ( p_error_msg VARCHAR2 )
  RETURN VARCHAR2;

  FUNCTION format_completion_date ( p_completion_date VARCHAR2 )
  RETURN VARCHAR2;
END CITCO_ERP_016_PKG;

/
--------------------------------------------------------
--  DDL for Package Body CITCO_ERP_016_PKG
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE PACKAGE BODY "CITCO_INT"."CITCO_ERP_016_PKG" 
AS
  FUNCTION format_error_msg ( p_error_msg VARCHAR2 )
  RETURN VARCHAR2
  IS
     l_error_msg VARCHAR2(2000):= NULL;
     l_formatted_error VARCHAR2(2000):= NULL;
     l_cdata_loc NUMBER:=0;
     l_period_loc NUMBER:=0;
     l_cdata_count NUMBER:=0;
  BEGIN
     l_error_msg := REPLACE(REPLACE(p_error_msg,',', ''),CHR(10),'' );

     l_cdata_count := INSTR(l_error_msg,'CDATA');

     IF l_cdata_count != 0
     THEN
         l_cdata_loc := INSTR(l_error_msg,'[CDATA[',1,2)+7;
         l_formatted_error := SUBSTR(l_error_msg, l_cdata_loc);
         l_period_loc := INSTR(l_formatted_error,'.',1,1);
         l_formatted_error := SUBSTR(l_formatted_error, 1, l_period_loc);
     ELSE
         l_formatted_error := l_error_msg;
     END IF;

     RETURN(l_formatted_error);
  EXCEPTION
     WHEN OTHERS THEN
     l_formatted_error := 'CITCO_ERP_016_PKG.format_error_msg - Failed to get formatted error message due to: '||SQLERRM||', Please check staging table ( CITCO_PRJ_BILLING_EVENT_011_STG ) for details';
     RETURN(l_formatted_error);
  END format_error_msg;

  FUNCTION format_completion_date ( p_completion_date VARCHAR2 )
  RETURN VARCHAR2
  IS
     -- Input Format: "DD-MON-YYYY"
     -- Output Format: "YYYY-MM-DD"
     l_completion_date VARCHAR2(30):= NULL;
     l_conv_date DATE:= NULL;
     l_formatted_date VARCHAR2(200):= NULL;
  BEGIN
     IF NVL(p_completion_date, 'N')  = 'N'
     THEN 
     l_formatted_date := '';
     RETURN(l_formatted_date);
     END IF;
     l_completion_date := UPPER(REPLACE(REPLACE(NVL(p_completion_date,'( NULL )'),',', ''),CHR(10),'' ));

     l_conv_date := TO_DATE(REPLACE(REPLACE(l_completion_date,',', ''),CHR(10),'' ),'DD-MON-YYYY') ;

     l_formatted_date := TO_CHAR(l_conv_date,'YYYY-MM-DD');

     RETURN(l_formatted_date);

  EXCEPTION
     WHEN OTHERS THEN
     l_formatted_date := 'CITCO_ERP_016_PKG.format_completion_date - Failed to format ( Date ): '||p_completion_date ||' INVALID DATE';
     RETURN(l_formatted_date);
  END format_completion_date;

END CITCO_ERP_016_PKG;

/