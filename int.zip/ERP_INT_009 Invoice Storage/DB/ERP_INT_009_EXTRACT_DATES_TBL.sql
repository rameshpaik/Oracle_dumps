/*-------------------------------------------------------------------------------
--
-- Version          Date         Author		       Comments             
-- 1.0          	02/06/2022   Mayank Kumar      Initial version
--
--
---------------------------------------------------------------------------------*/
  CREATE TABLE "CITCO_INT"."ERP_INT_009_EXTRACT_DATES" 
   (	"RECORD_IDENTIFIER" NUMBER GENERATED ALWAYS AS IDENTITY MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  NOT NULL ENABLE, 
	"LAST_EXTRACT_DATE" DATE, 
	"INTEGRATION_ID" NUMBER, 
	"FILENAME" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP", 
	"DOCUMENT_ID" NUMBER
   );