/*-------------------------------------------------------------------------------
--
-- Version          Date         Author		       Comments             
-- 1.0          	02/06/2022   Mayank Kumar      Initial version
--
--
---------------------------------------------------------------------------------*/
  CREATE TABLE "CITCO_INT"."ERP_INT_009_INTERFACE_RUNS" 
   (	"RECORD_IDENTIFIER" NUMBER GENERATED ALWAYS AS IDENTITY MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  NOT NULL ENABLE, 
	"CREATION_DATE" DATE, 
	"CREATED_BY" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP", 
	"INTEGRATION_ID" NUMBER, 
	"INTEGRATION_NAME" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP", 
	"LASTRUNDATE" DATE
   );