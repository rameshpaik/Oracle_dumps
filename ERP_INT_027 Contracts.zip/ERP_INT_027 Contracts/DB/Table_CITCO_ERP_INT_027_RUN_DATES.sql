/*------------------------------------------------------------------------------- 
-- 
-- Version   Date           Author          Comments              
-- 1.0       25/01/2023     Munna Prasad   Initial version 
-- 
-- 
---------------------------------------------------------------------------------*/ 
drop table CITCO_ERP_INT_027_RUN_DATES;

CREATE TABLE CITCO_ERP_INT_027_RUN_DATES
   (	
   "INTEGRATION_ID" NUMBER, 
	"LAST_EXTRACT_DATE" DATE, 
	"BU" VARCHAR2(100 BYTE) ,
	"STATUS" VARCHAR2(10 BYTE) 
   ) ;